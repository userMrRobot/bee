-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: MySQL-8.2
-- Время создания: Ноя 05 2024 г., 12:57
-- Версия сервера: 8.2.0
-- Версия PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `bird`
--

-- --------------------------------------------------------

--
-- Структура таблицы `gameMoney`
--

CREATE TABLE `gameMoney` (
  `id` int NOT NULL,
  `silver` int NOT NULL DEFAULT '0',
  `gold` int NOT NULL DEFAULT '0',
  `rub` int NOT NULL DEFAULT '0',
  `credit_silver` int NOT NULL DEFAULT '0',
  `credit_silver_all` int NOT NULL DEFAULT '0',
  `med` int NOT NULL DEFAULT '0',
  `medAll` int DEFAULT '0',
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `login`
--

CREATE TABLE `login` (
  `id` int NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nikName` varchar(55) NOT NULL,
  `role` varchar(55) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `register_data`
--

CREATE TABLE `register_data` (
  `id` int NOT NULL,
  `time_last` int DEFAULT '0',
  `data_reg_credit` date DEFAULT NULL,
  `data_pay_credit` int NOT NULL DEFAULT '0',
  `time_get_credit` int NOT NULL DEFAULT '0',
  `time_set_credit` int NOT NULL DEFAULT '0',
  `day_for_credit` int DEFAULT '0',
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `user_bee`
--

CREATE TABLE `user_bee` (
  `id` int NOT NULL,
  `bee1` int NOT NULL DEFAULT '0',
  `bee2` int NOT NULL DEFAULT '0',
  `bee3` int NOT NULL DEFAULT '0',
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `gameMoney`
--
ALTER TABLE `gameMoney`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `register_data`
--
ALTER TABLE `register_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `user_bee`
--
ALTER TABLE `user_bee`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `gameMoney`
--
ALTER TABLE `gameMoney`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `login`
--
ALTER TABLE `login`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `register_data`
--
ALTER TABLE `register_data`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `user_bee`
--
ALTER TABLE `user_bee`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `gameMoney`
--
ALTER TABLE `gameMoney`
  ADD CONSTRAINT `gamemoney_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `login` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `register_data`
--
ALTER TABLE `register_data`
  ADD CONSTRAINT `register_data_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `login` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `user_bee`
--
ALTER TABLE `user_bee`
  ADD CONSTRAINT `user_bee_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `login` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
